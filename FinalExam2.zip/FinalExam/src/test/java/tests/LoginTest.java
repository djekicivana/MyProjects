package tests;

import org.testng.annotations.Test;
import pages.LoginPage;
import pages.VerificationPage;
import utilities.PropertyManager;

public class LoginTest extends BaseTest{

    @Test
    public void validLogin(){
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(PropertyManager.getInstance().getValidUsername(), PropertyManager.getInstance().getValidPassword());
        VerificationPage verificationPage = new VerificationPage(driver);
        verificationPage.verifyLogin("Name (A to Z)\n" + "Name (Z to A)\n" + "Price (low to high)\n" + "Price (high to low)");
    }
}


