package tests;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.VerificationPage;
import utilities.PropertyManager;

public class FailedLoginTest extends BaseTest {

    @Test(dataProvider = "failedLogin")

    public void failedLogin(String email, String password, String errorMessage) {
        LoginPage loginPage = new LoginPage(driver);
        VerificationPage verificationPage = new VerificationPage(driver);
        loginPage.failedLogin(email, password);
        verificationPage.verifyFailedLogin(errorMessage);
    }

    @DataProvider(name = "failedLogin")

    public Object[][] dpMethod() {
        return new Object[][]{
                {"", PropertyManager.getInstance().getValidPassword(), "Epic sadface: Username is required"},
                {PropertyManager.getInstance().getValidUsername(), "", "Epic sadface: Password is required"},
                {PropertyManager.getInstance().getBadUsername(), PropertyManager.getInstance().getBadPassword(), "Epic sadface: Username and password do not match any user in this service"},
        };
    }
}
