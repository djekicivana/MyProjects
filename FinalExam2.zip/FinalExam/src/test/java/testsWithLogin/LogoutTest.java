package testsWithLogin;

import org.testng.annotations.Test;
import pages.UserLoggedInPage;
import pages.VerificationPage;
import testsWithLogin.BaseTestWithLogin;

public class LogoutTest extends BaseTestWithLogin {

    @Test
    public void logout() {
        UserLoggedInPage userLoggedInPage = new UserLoggedInPage(driver);
        VerificationPage verificationPage = new VerificationPage(driver);
        userLoggedInPage.logout();
        verificationPage.verifyLogout("Password for all users:\n" +
                                                "secret_sauce");
    }
}
