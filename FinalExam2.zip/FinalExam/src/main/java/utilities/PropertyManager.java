package utilities;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyManager {

    private static PropertyManager instance;
    private static String configPath = "src/main/resources/configuration.properties";
    private static String driverPath;
    private static String validUsername;
    private static String validPassword;
    private static String badUsername;
    private static String badPassword;
    private static String firstName;
    private static String lastName;
    private static String postalCode;

    public static PropertyManager getInstance() {
        if (instance == null) {
            instance = new PropertyManager();
            instance.loadData();
        }
        System.out.println(instance);
        return instance;
    }

    public String getValidUsername() {
        return validUsername;
    }

    public String getValidPassword() {
        return validPassword;
    }

    public String getBadUsername() {
        return badUsername;
    }

    public String getBadPassword() {
        return badPassword;
    }

    public String getFirstName() { return firstName; }

    public String getLastName() { return lastName; }

    public String getPostalCode() { return postalCode; }

    private void loadData() {
        Properties properties = new Properties();
        try {
            FileInputStream fi = new FileInputStream(configPath);
            properties.load(fi);
        } catch (Exception e) {
            e.printStackTrace();
        }

        driverPath = properties.getProperty("driverPath");
        validUsername = properties.getProperty("validUsername");
        validPassword = properties.getProperty("validPassword");
        badUsername = properties.getProperty("badUsername");
        badPassword = properties.getProperty("badPassword");
        firstName = properties.getProperty("firstName");
        lastName = properties.getProperty("lastName");
        postalCode = properties.getProperty("postalCode");

    }
}
