package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage extends BasePage{
    public LoginPage(WebDriver driver) {
        super(driver);
    }
    By userNameFieldBy = By.id("user-name");
    By passwordFieldBy = By.id("password");
    By loginButtonBy = By.id("login-button");

    public void login(String username, String password) {
        writeText(userNameFieldBy, username);
        writeText(passwordFieldBy, password);
        click(loginButtonBy);
    }
    public void failedLogin(String badUsername, String badPassword){
        writeText(userNameFieldBy, badUsername);
        writeText(passwordFieldBy, badPassword);
        click(loginButtonBy);
    }

}

