package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class VerificationPage extends BasePage{
    public VerificationPage(WebDriver driver) {
        super(driver);
    }


    By errorBy = By.xpath("//div[@class='error-message-container error']");
    By passwordTextBy = By.className("login_password");
    By completeOrderBy = By.className("complete-text");
    By addToCartButtonBy = By.id("add-to-cart-sauce-labs-backpack");
    By checkItemBy = By.id("item_3_title_link");


    public void verifyFailedLogin(String expectedText){
        assertStringEquals(readText(errorBy), expectedText);
    }
    public void verifyLogout(String expectedText) {
        assertStringEquals(readText(passwordTextBy), expectedText);
    }
    public void verifyPurchase(String expectedText) {
        assertStringEquals(readText(completeOrderBy), expectedText);
    }
    public void verifyRemovedItem (String expectedText) {
        assertStringEquals(readText(addToCartButtonBy), expectedText); }
    public void verifyCheckedItem (String expectedText) {
        assertStringEquals(readText(checkItemBy), expectedText); }

}
