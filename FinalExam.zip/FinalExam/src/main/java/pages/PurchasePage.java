package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class PurchasePage extends BasePage {
    public PurchasePage(WebDriver driver) {
        super(driver);
    }
    By addToCartButtonBy = By.id("add-to-cart-sauce-labs-backpack");
    By shoppingCartButtonBy = By.className("shopping_cart_link");
    By removeButtonBy = By.id("remove-sauce-labs-backpack");
    By checkoutButtonBy = By.id("checkout");
    By continueShoppingButtonBy = By.id("continue-shopping");
    By firstNameFieldBy = By.id("first-name");
    By lastNameFieldBy = By.id("last-name");
    By postalCodeFieldBy = By.id("postal-code");
    By continueButtonBy = By.name("continue");
    By finishButtonBy = By.id("finish");
    By checkCorrectItemBy = By.id("add-to-cart-test.allthethings()-t-shirt-(red)");
    By firstItemNameBy = By.className("inventory_item_name");


    public void purchase (String firstName, String lastName, String postalCode) {
        click(addToCartButtonBy);
        click(shoppingCartButtonBy);

        WebElement element = driver.findElement(firstItemNameBy);
        if (element.getText().equals("Sauce Labs Backpack"))
            System.out.println("Same item");
        else
            System.out.println("Different item");
        Assert.assertEquals(element.getText(), "Sauce Labs Backpack" );

        click(checkoutButtonBy);
        writeText(firstNameFieldBy, firstName);
        writeText(lastNameFieldBy, lastName);
        writeText(postalCodeFieldBy, postalCode);
        click(continueButtonBy);
        click(finishButtonBy);
    }

    public void removeItem () {
        click(addToCartButtonBy);
        click(shoppingCartButtonBy);
        click(removeButtonBy);
        click(continueShoppingButtonBy);
    }

    public void checkIfCorrectItem() {
        click(checkCorrectItemBy);
        click(shoppingCartButtonBy);
    }
}
