package testsWithLogin;

import org.testng.annotations.Test;
import pages.PurchasePage;
import pages.VerificationPage;
import testsWithLogin.BaseTestWithLogin;

public class RemoveItemTest extends BaseTestWithLogin {

    @Test
    public void removeTheItem() {
        PurchasePage purchasePage = new PurchasePage(driver);
        VerificationPage verificationPage = new VerificationPage(driver);
        purchasePage.removeItem();
        verificationPage.verifyRemovedItem("ADD TO CART");
    }
}
