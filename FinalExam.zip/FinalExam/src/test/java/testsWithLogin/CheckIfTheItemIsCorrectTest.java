package testsWithLogin;

import org.testng.annotations.Test;
import pages.PurchasePage;
import pages.VerificationPage;

public class CheckIfTheItemIsCorrectTest extends BaseTestWithLogin {

    @Test
    public void checkItem () {
        PurchasePage purchasePage = new PurchasePage(driver);
        purchasePage.checkIfCorrectItem();
        VerificationPage verificationPage = new VerificationPage(driver);
        verificationPage.verifyCheckedItem("Test.allTheThings() T-Shirt (Red)");
    }
}
