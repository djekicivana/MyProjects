package testsWithLogin;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.PurchasePage;
import pages.VerificationPage;
import testsWithLogin.BaseTestWithLogin;
import utilities.PropertyManager;

public class PurchaseTest extends BaseTestWithLogin {

@Test
    public void purchase () {
    PurchasePage purchasePage = new PurchasePage(driver);
    VerificationPage verificationPage = new VerificationPage(driver);
    purchasePage.purchase(PropertyManager.getInstance().getFirstName(), PropertyManager.getInstance().getLastName(), PropertyManager.getInstance().getPostalCode());
//    purchasePage.checkIfCorrectItem();
//    verificationPage.verifyCheckedItem("Test.allTheThings() T-Shirt (Red)");
    verificationPage.verifyPurchase("Your order has been dispatched, and will arrive just as fast as the pony can get there!");
}
}
